package com.study.domain;

import lombok.Data;

/**
 * @author fjding
 * @date 2021/11/29
 */
@Data
public class Good {

    private String id;
}
