package com.study.aspect;

/**
 * 通知
 *
 * @author fjding
 * @date 2021/11/28
 */

public class AspectAdvice  {


}
