/**
 * 如果有多个通知，可以通过注解@Order或实现Ordered接口排序，
 * value值越小，优先级越高
 *
 * @author fjding
 * @date 2021/11/29
 */
package com.study.aspect.order;