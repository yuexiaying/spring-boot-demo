package com.study.aspect.model;

import org.springframework.stereotype.Component;

/**
 * todo 没搞懂是啥意思
 * @author fjding
 * @date 2021/11/29
 */
@Component
public class SimpleModel {
}
